#include <stdio.h>		
#include <stdlib.h>		
#include <sys/types.h>		
#include <sys/socket.h>	
#include <unistd.h>			
#include <netinet/in.h>		
#include <arpa/inet.h>		
#include <string.h>	
#include <errno.h>
#include <signal.h>

struct pdu_cli{
	short cid;
	char str[80];
};

struct pdu_srv{
	short vcd;
	char str[80];
};

void cli_biz(int clientfd, char *cid);

int main(int argc, char **argv){

	int clientfd, numbytes;
	struct sockaddr_in server_addr;
	
	int pid = getpid();
	char mypid[6];  
	sprintf(mypid, "%d", pid);

	clientfd = socket(AF_INET,SOCK_STREAM,0);
	if( clientfd == -1 ){
        	perror("socket create failure!");
        	exit(EXIT_FAILURE);
    	}

	memset(&server_addr, 0, sizeof(server_addr));
    	server_addr.sin_family = AF_INET;
    	server_addr.sin_port = htons(atoi(argv[2]));
    	if(inet_pton(AF_INET, argv[1], &server_addr.sin_addr)==0){
    		perror("inet_pton ERROR");
        	exit(EXIT_FAILURE);
    	};
    	
    	
	if(connect(clientfd, (struct sockaddr *)&server_addr, sizeof(struct sockaddr))==-1){
	perror("connect error");
        exit(EXIT_FAILURE);
        };
	printf("[cli](%s)[srv_sa](%s:%s) Server is connected!\n",mypid,argv[1],argv[2]);
	

	cli_biz(clientfd,argv[3]);
	close(clientfd);
	printf("[cli](%s) connfd is closed!\n",mypid);
    	printf("[cli](%s) client is to return!\n",mypid);
	return 0;
}

void cli_biz(int clientfd,char *cid){
	while(1){
		int pid = getpid();
		char mypid[6];  
		sprintf(mypid, "%d", pid);
		
		struct pdu_srv r;
		struct pdu_cli response;
		bzero(&r,sizeof(struct pdu_srv));
		bzero(&response,sizeof(struct pdu_cli));
		
		fgets(response.str, 80,stdin);
		if(strcmp(response.str,"EXIT\n")==0)
			return;
		printf("[cli](%s)[cid](%s)[ECH_RQT] %s",mypid,cid,response.str);
		response.cid = htons(strtol(cid,NULL,10));
		write(clientfd,&response,sizeof(struct pdu_cli));
		
		read(clientfd,&r.vcd,2);
		read(clientfd,&r.str,sizeof(struct pdu_srv)-2);
		printf("[cli](%s)[vcd](%d)[ECH_REP] %s",mypid,ntohs(r.vcd),r.str);
		
	}
}
