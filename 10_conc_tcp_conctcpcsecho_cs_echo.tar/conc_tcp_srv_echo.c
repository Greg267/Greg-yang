#include <stdio.h>		
#include <stdlib.h>		
#include <unistd.h>		
#include <sys/types.h>		
#include <sys/socket.h>		
#include <netinet/in.h>		
#include <arpa/inet.h>		
#include <string.h>	
#include <errno.h>
#include <signal.h>	
#include <sys/wait.h>

struct pdu_cli{
	short cid;
	char str[80];
};

struct pdu_srv{
	short vcd;
	char str[80];
};


volatile sig_atomic_t sigint_flag = 0;

void srv_biz(int connectfd, char *str);
void handle_sigint(int signo);
void sig_chld(int signo);

void handle_sigint(int sig){
	printf("[srv] SIGINT is coming!\n");
	sigint_flag = 1;
}

void sig_chld(int signo){
	pid_t pid_chld;
	int stat;
	while((pid_chld=waitpid(-1,&stat,WNOHANG))>0){
		int pid = getpid();
		char mypid[6];  
		sprintf(mypid, "%d", pid);
		printf("[srv](%s)[chd](%d) Child has terminated!\n",mypid,pid_chld);
	};
	
}

int main(int argc, char **argv){
	struct sockaddr_in server;

	
	int pid = getpid();
	char mypid[6];  
	sprintf(mypid, "%d", pid);
	
	
	struct sigaction sa;
	memset(&sa, 0, sizeof(sa));
	sa.sa_handler=handle_sigint;
	sigemptyset(&sa.sa_mask);
	if(sigaction(SIGINT,&sa,NULL)==-1){
		perror("sigaction error");
        	exit(EXIT_FAILURE);
	};
	
	struct sigaction sa1;
	memset(&sa1, 0, sizeof(sa1));
	sa1.sa_flags =0;
	sa1.sa_handler=sig_chld;
	sigemptyset(&sa1.sa_mask);
	if(sigaction(SIGCHLD,&sa1,NULL)==-1){
		perror("sigaction error");
        	exit(EXIT_FAILURE);
	};
	

	
	
	
	int listenfd = socket(AF_INET,SOCK_STREAM,0);
	    if( listenfd == -1 ){
        	perror("socket create failure!");
        	exit(EXIT_FAILURE);
    		}
    		

	
	memset(&server, 0, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_port = htons(atoi(argv[2]));
	
    	if(inet_pton(AF_INET, argv[1], &server.sin_addr) == 0){
        	perror("inet_pton error");
        	exit(EXIT_FAILURE);
    	}
	bind(listenfd,(struct sockaddr *)&server,sizeof(struct sockaddr));
	if(listen(listenfd,5)==-1){
        	perror("listen socket error!");
        	exit(EXIT_FAILURE);
    	};
	printf("[srv](%s)[srv_sa](%s:%s)[vcd](%s) Server has initialized\n",mypid,argv[1],argv[2],argv[3]);
	while(!sigint_flag){
		struct sockaddr_in client;
		int sin_size = sizeof(struct sockaddr_in);
		int connfd = accept(listenfd, (struct sockaddr *)&client, &sin_size);
		
		if(connfd<0){
			if(errno==EINTR)
				continue;
			else{
           		perror("accept error");
               		exit(0);
           			}
           					
           	}	
		
		int pid;
		pid = fork();
		if(pid<0){
			perror("fork error");
			return 0;
		}
		if(pid>0){
			close(connfd);
		}
		if(pid==0){
			close(listenfd);
			srv_biz(connfd,argv[3]);
			close(connfd);
			return 0;
		}


		
	}
	
	
	
	close(listenfd);
	printf("[srv] listenfd is closed!\n");
	printf("[srv] server is going to exit!\n");
	return 0;

}


void srv_biz(int connfd,char *str){
	while(!sigint_flag){
		struct pdu_cli r;
		struct pdu_srv response;
		bzero(&r,sizeof(struct pdu_cli));
		bzero(&response,sizeof(struct pdu_srv));
		
		ssize_t size_read = read(connfd,&r.cid,2);
		if (size_read == 0){
			return;
		}
		ssize_t size_read2 = read(connfd,&r.str,sizeof(r.str));
		if (size_read2 == 0){
			return;
		}
		printf("[chd](%d)[cid](%d)[ECH_RQT] %s",getpid(),ntohs(r.cid),r.str);
		sprintf(response.str,"%s",r.str);
		response.vcd = htons(strtol(str,NULL,10));
		ssize_t size_write = write(connfd,&response,sizeof(struct pdu_srv));
		
	}
}


