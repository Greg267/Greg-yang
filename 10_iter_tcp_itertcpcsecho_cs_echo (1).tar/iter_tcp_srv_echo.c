//
// Created by 11407 on 2023/5/11.
//
#include <stdio.h>
#include <stdlib.h>		//exit()函数相关
#include <unistd.h>		//C 和 C++ 程序设计语言中提供对 POSIX 操作系统 API 的访问功能的头文件
#include <sys/types.h>		//Unix/Linux系统的基本系统数据类型的头文件,含有size_t,time_t,pid_t等类型
#include <sys/socket.h>		//套接字基本函数相关
#include <netinet/in.h>		//IP地址和端口相关定义，比如struct sockaddr_in等
#include <arpa/inet.h>		//inet_pton()等函数相关
#include <string.h>		//bzero()函数相关
#include <signal.h>
#include <errno.h>

#define BACKLOG 5
#define MAX_MSG_LEN 130
struct udp{
    char buffer[MAX_MSG_LEN];
};
struct udp_r{
    char buffer[140];
};


volatile sig_atomic_t sigint_flag = 0;
void sig_int(int signo);
void serv_biz(int connectfd, char *string);

int main(int argc, char *argv[]) {
    //判断命令行用法
    if (argc != 4) {
        printf("Usage: %s <server IP address> <server port> <vericode> \n", argv[0]);
        exit(0);
    }

    // 处理SIGINT信号
    struct sigaction act;
    memset(&act, 0, sizeof(act));
    act.sa_handler = sig_int;
    if (sigaction(SIGINT, &act, NULL) == -1) {
        perror("sigaction error");
        exit(EXIT_FAILURE);
    }

    //创建套接字
    int listenfd = socket(AF_INET, SOCK_STREAM, 0);
    if( listenfd == -1 ){
        perror("socket create failure!");
        exit(EXIT_FAILURE);
    }


    //创建套接字赋值并与套接字绑定
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(atoi(argv[2]));
    if(inet_pton(AF_INET, argv[1], &addr.sin_addr) == 0){
        perror("inet_pton ERROR");
        exit(EXIT_FAILURE);
    }

    if(bind(listenfd, (struct sockaddr *)&addr,sizeof(struct sockaddr)) == -1){
        perror("bind socket error!");
        exit(EXIT_FAILURE);
    }

    //设置监听套接字
    if(listen(listenfd,BACKLOG) == -1) {
        perror("listen socket error!");
        exit(EXIT_FAILURE);
    }else{
        //建立监听后打印
        printf("[srv] server[%s:%s][%s] is initializing\n", argv[1], argv[2],argv[3]);
    }

    while(!sigint_flag){
        int sin_size = sizeof(struct sockaddr_in);
        int connectfd = accept(listenfd, (struct sockaddr *)&addr,&sin_size);
        if (connectfd < 0) {
            if(errno == EINTR){
                continue;
            } else{
                perror("accept error");
                exit(0);
            }
        } else{
            //受到客户端请求后打印客户端信息
            struct sockaddr_in client_addr;
            socklen_t client_addr_len = sizeof(client_addr);
            getpeername(connectfd, (struct sockaddr *)&client_addr, &client_addr_len);
            char clientmessage[50];
            char port_str[6];
            sprintf(port_str, "%hu", ntohs(client_addr.sin_port));
            printf("[srv] client[%s:%s] is accepted\n",inet_ntoa(client_addr.sin_addr), port_str);
            sprintf(clientmessage,"[srv] client[%s:%s] is closed\n",inet_ntoa(client_addr.sin_addr), port_str);

            serv_biz(connectfd, argv[3]);

            close(connectfd);
            printf("%s", clientmessage);

        }
    }
    close(listenfd);
    printf("[srv] listenfd is closed!\n");
    printf("[srv] server is going to exit!\n");
    return 0;
}

void serv_biz(int connectfd,char *string) {

    while(!sigint_flag){
        struct udp udp_1;
        struct udp_r udp_2;
        bzero(&udp_1, sizeof(struct udp));
        bzero(&udp_2, sizeof(struct udp_r));
        ssize_t size_read= read(connectfd, &udp_1, sizeof(udp_1));
        if(size_read == 0){
            return;
        }
        printf("[ECH_RQT]%s",udp_1.buffer);
        sprintf(udp_2.buffer,"(%s)%s",string,udp_1.buffer);
        write(connectfd, &udp_2, sizeof(udp_2));
    }
}

void sig_int(int signo)
{
    printf("[srv] SIGINT is coming!\n");
    sigint_flag = 1;
}
