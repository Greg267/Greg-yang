//
// Created by 11407 on 2023/5/11.
//
#include <stdio.h>
#include <stdlib.h>		//exit()函数，atoi()函数
#include <unistd.h>		//C 和 C++ 程序设计语言中提供对 POSIX 操作系统 API 的访问功能的头文件
#include <sys/types.h>		//Unix/Linux系统的基本系统数据类型的头文件,含有size_t,time_t,pid_t等类型
#include <sys/socket.h>		//套接字基本函数
#include <netinet/in.h>		//IP地址和端口相关定义，比如struct sockaddr_in等
#include <arpa/inet.h>		//inet_pton()等函数
#include <string.h>		//bzero()函数


#define MAX_MSG_LEN 130
void cli_biz(int clientfd);

struct udp{
    char buffer[MAX_MSG_LEN];
};
struct udp_r{
    char buffer[140];
};


int main(int argc, char *argv[])
{

    //判断命令行用法
    if(argc != 3){
        printf("Usage: %s <server IP address> <server port> \n" ,argv[0]);
        exit(0);
    }


    //创建客户端套接字
    int clientfd = socket(AF_INET, SOCK_STREAM, 0);
    if( clientfd == -1 ){
        perror("socket create failure!");
        exit(EXIT_FAILURE);
    }

    //创建服务器的套接字赋值,IP和端口均从命令行获取
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(atoi(argv[2]));
    if(inet_pton(AF_INET, argv[1], &addr.sin_addr) == 0){
        perror("inet_pton ERROR");
        exit(EXIT_FAILURE);
    }
    //建立连接
    if(connect(clientfd,(struct sockaddr *)&addr,sizeof(struct sockaddr)) == -1) {
        perror("connect error");
        exit(EXIT_FAILURE);
    }else{
        printf("[cli] server[%s:%s] is connected!\n",argv[1],argv[2]);
    }

    cli_biz(clientfd);

    close(clientfd);
    printf("[cli] connfd is closed!\n");

    printf("[cli] client is to return!\n");
    return 0;

}

void cli_biz(int clientfd) {
    //发送业务数据小循环
    while (1) {
        struct udp udp_1;
        struct udp_r udp_2;
        bzero(&udp_1, sizeof(struct udp));
        bzero(&udp_2, sizeof(struct udp_r));
        fgets(udp_1.buffer, MAX_MSG_LEN,stdin);
        printf("[ECH_RQT]%s",udp_1.buffer);
        if(strcmp(udp_1.buffer,"EXIT\n")==0){
            return;
        }
        
        write(clientfd,&udp_1,sizeof(udp_1));

        read(clientfd,&udp_2,sizeof(udp_2));
        printf("[ECH_REP]%s",udp_2.buffer);
    }
}
